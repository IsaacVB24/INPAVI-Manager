# INPAVI-Manager
Desarrollo por cuenta propia de mi TT para la ONG INPAVI
